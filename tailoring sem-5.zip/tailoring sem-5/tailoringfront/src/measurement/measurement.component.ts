import { ApiService } from 'src/app/api.service';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';




@Component({
  selector: 'app-measurement',
  templateUrl: './measurement.component.html',
  styleUrls: ['./measurement.component.css']
})
export class MeasurementComponent implements OnInit {

  formdata: any;
  message = "";

  constructor(private api: ApiService, private router: Router) { }

  ngOnInit(): void {
    this.formdata = new FormGroup({
      name: new FormControl("", Validators.required),
      product: new FormControl("", Validators.required),
      height: new FormControl("", Validators.required),
      weight: new FormControl("", Validators.required),
      wrist: new FormControl("", Validators.required),
      shoulder: new FormControl("", Validators.required),
      chest: new FormControl("", Validators.required),
      waist: new FormControl("", Validators.required),
      outseam: new FormControl("", Validators.required),
      inseam: new FormControl("", Validators.required),

    })
  }
  submit(data: any) {
    if (data.name != data.name) {
      alert("name is required.");
    }

    this.api.post("measurement/create", { data: data }).subscribe((result: any) => {
      if (result.status == "success") {
        localStorage.setItem("name", data.name);
        localStorage.setItem("product", data.product);
        localStorage.setItem("height", data.height);
        localStorage.setItem("weight", data.weight);
        localStorage.setItem("wrist", data.wrist);
        localStorage.setItem("shoulder", data.shoulder);
        localStorage.setItem("chest", data.chest);
        localStorage.setItem("waist", data.waist);
        localStorage.setItem("outseam", data.outseam);
        localStorage.setItem("inseam", data.inseam);
      }
      else {
        this.message = result.data;
      }
    })

  }
}
