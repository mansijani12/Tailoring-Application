let express = require("express");
let bodyparser = require("body-parser");
let Measurement = require("../models/Measurement");

let router = express.Router();

router.post("/create", async (req, res) => {
    try {
        let body = req.body;
        let measurement = new Measurement;
        measurement.name = body.data.name;
        measurement.product = body.data.product;
        measurement.height = body.data.height;
        measurement.weight = body.data.weight;
        measurement.wrist = body.data.wrist;
        measurement.shoulder = body.data.shoulder;
        measurement.chest = body.data.chest;
        measurement.waist = body.data.waist;
        measurement.inseam = body.data.inseam;
        measurement.outseam = body.data.outseam;
        measurement.save().then(result => {
            res.end(JSON.stringify({ staus: "success", data: result }));
        }, err => {
            res.end(JSON.stringify({ staus: "failed", data: err }));
        });
    }
    catch {
        res.end(JSON.stringify({ staus: "failed", data: "something went wrong" }));
    }

});

module.exports = router;